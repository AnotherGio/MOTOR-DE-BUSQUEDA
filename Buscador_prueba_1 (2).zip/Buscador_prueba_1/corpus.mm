%%MatrixMarket matrix coordinate real general
0 0 0                                             
